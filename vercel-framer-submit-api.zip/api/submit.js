export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { name, company, phone, message } = req.body;

    const response = await fetch(
      'https://script.google.com/macros/s/AKfycbxh_1oPMtn113PZiYmdvFxYiOzt46tFRQQyd9EH_ES9xtdVtBlAwL49YIoaBG1Jz1OI/exec',
      {
        method: 'POST',
        body: JSON.stringify({ name, company, phone, message }),
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    if (response.ok) {
      res.status(200).json({ message: '구글시트 전송 완료!' });
    } else {
      res.status(500).json({ message: '서버 오류!' });
    }
  } else {
    res.status(405).json({ message: '허용되지 않은 메서드입니다.' });
  }
}
